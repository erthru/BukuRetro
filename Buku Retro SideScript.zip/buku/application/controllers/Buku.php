<?php

defined('BASEPATH') OR exit('No Direct Script Allowed');
require APPPATH . 'libraries/REST_Controller.php';

class Buku extends REST_Controller{

  public function __construct(){
    parent::__construct();
  }

  private function fieldkosong(){

    $response['error']=1;
    $response['pesan']='Tidak boleh ada field yang kosong';
    $this->response($response);

  }

  public function semua_get(){

    $semua = $this->db->query("SELECT * FROM daftarbuku ORDER BY id DESC")->result();

    $response['error']=0;
    $response['data']=$semua;
    $this->response($response);

  }

  public function tambah_post(){

    $judul = $this->post('judul');
    $penerbit = $this->post('penerbit');
    $tglterbit = $this->post('tglterbit');

    if(!$judul || !$penerbit || !$tglterbit){

      $this->fieldkosong();

    }else{

      $tambah = $this->db->query("INSERT INTO daftarbuku VALUES ('','$judul','$penerbit','$tglterbit')");

      if($tambah){
        $response['error']=0;
        $response['pesan']='Buku berhasil ditambahkan';
        $this->response($response);
      }else{
        $response['error']=1;
        $response['pesan']='Buku gagal ditambahkan';
        $this->response($response);
      }

    }

  }


  public function edit_put(){

    $id = $this->put('id');
    $judul = $this->put('judul');
    $penerbit = $this->put('penerbit');
    $tglterbit = $this->put('tglterbit');

    if(!$id || !$judul || !$penerbit || !$tglterbit){

      $this->fieldkosong();

    }else{

      $edit = $this->db->query("UPDATE daftarbuku SET judul='$judul', penerbit='$penerbit',  tglterbit='$tglterbit' WHERE id='$id'");

      if($edit){
        $response['error']=0;
        $response['pesan']='Buku berhasil diedit';
        $this->response($response);
      }else{
        $response['error']=1;
        $response['pesan']='Buku gagal diedit';
        $this->response($response);
      }

    }

  }

  public function hapus_get(){

    $id = $this->get('id');

    if(!$id){

      $this->fieldkosong();

    }else{

      $hapus = $this->db->query("DELETE FROM daftarbuku WHERE id='$id'");

      if($hapus){
        $response['error']=0;
        $response['pesan']='Buku berhasil dihapus';
        $this->response($response);
      }else{
        $response['error']=1;
        $response['pesan']='Buku gagal dihapus';
        $this->response($response);
      }

    }

  }

}

?>
