-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 07 Jun 2018 pada 11.48
-- Versi Server: 5.5.39
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `buku`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `daftarbuku`
--

CREATE TABLE IF NOT EXISTS `daftarbuku` (
`id` int(20) NOT NULL,
  `judul` text,
  `penerbit` text,
  `tglterbit` date DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data untuk tabel `daftarbuku`
--

INSERT INTO `daftarbuku` (`id`, `judul`, `penerbit`, `tglterbit`) VALUES
(3, 'Bedah retrofit', 'Squre', '2018-01-10'),
(4, 'Tutorial CRUD Android', 'bapercoding.com', '2018-04-04'),
(5, 'Tutorial Postman', 'postman', '2018-10-29'),
(6, 'FAN VS Retrofit 2', 'Gue lah', '2017-12-05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `daftarbuku`
--
ALTER TABLE `daftarbuku`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `daftarbuku`
--
ALTER TABLE `daftarbuku`
MODIFY `id` int(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
